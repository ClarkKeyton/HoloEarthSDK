// Generated C++ file by Il2CppInspector - http://www.djkaty.com - https://github.com/djkaty
// IL2CPP application initializer

#pragma once

// IL2CPP application initializer
void init_il2cpp();